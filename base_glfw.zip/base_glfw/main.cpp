#include <iostream>
#include <vector>
#include <cassert>
#include <string>
#include <cmath>

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "util.hpp"
#include "mesh.hpp"
// image-loading function
#include "stb_image.h"
#include "stb_image_write.h"
// dear imgui: standalone example application for GLFW + OpenGL 3, using programmable pipeline
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "ImGuiFileDialog.h"

// [Win32] Our example includes a copy of glfw3.lib pre-compiled with VS2010 to maximize ease of testing and compatibility with old VS compilers.
// To link with VS2010-era libraries, VS2015+ requires linking with legacy_stdio_definitions.lib, which we do using this pragma.
// Your own project should not be affected, as you are likely to link with a newer binary of GLFW that is adequate for your version of Visual Studio.
#if defined(_MSC_VER) && (_MSC_VER >= 1900) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS)
#pragma comment(lib, "legacy_stdio_definitions")
#endif

#define M_PI 3.1415926535897932384626433832795

// Window handle.
GLFWwindow* window = nullptr;
int windowWidth = 800, windowHeight = 600;

// Shaders, location to uniform variables, and vertex array objects.
// Object
void prepareObject();
GLuint VAO_o[2], VBO_o[2]; 
GLuint shader_o[2]; // [0] is the left object, [1] is the right object.
GLuint transformLoc[2];
GLuint isPaintingLoc[2];
GLuint texture1DLoc[2][128];
GLuint cameraPosLoc[2];
float texture1D[128];
Mesh *mesh[2];
float Px, Py; // Translation of the object
// Painting
void prepareQuad();
GLuint VAO_p, VBO_p;
GLuint shader_p;
glm::vec2 shader_vert, texture_vert;
// Prepares the texture.
// This function generates an interesting image by writing a 2D array,
//   and sends it over GPU and manage it as a texture.
bool prepareBackground(const char * image_filename);
bool preparePaintedObj();
// Similar as VAO and VBOs, texture in OpenGL are also unsigned integers.
GLuint texture_obj, texture_bg;
GLuint tex_unit_objLoc, tex_unit_bgLoc;
// OpenGL supports at least 16 texture units (so that a shader can refer to multiple textures).
// We are going to use the 0-th texture unit. The unit's index is sent over to the shader.
constexpr GLuint kTextureUnitInUse_obj = 0;
constexpr GLuint kTextureUnitInUse_bg = 1;

// camera
glm::vec3 camCoords = glm::vec3(0.0, 0.0, 1.0);
bool camRot = false;
glm::vec2 camOrigin;
glm::vec2 mouseOrigin;

// GLFW window callbacks to handle keyboard and mouse input.
void scrollCallback(GLFWwindow* w, double x, double y);
void keyCallback(GLFWwindow* w, int key, int sc, int action, int mode);
void mouseButtonCallback(GLFWwindow* w, int b, int action, int mode);
void cursorPosCallback(GLFWwindow* w, double xp, double yp);
void framebufferSizeCallback(GLFWwindow* w, int width, int height);

static void glfw_error_callback(int error, const char* description)
{
	fprintf(stderr, "Glfw Error %d: %s\n", error, description);
}

int main() {
	std::cout << "Hello, OpenGL!" << std::endl;
	//initGLFW();
	glfwSetErrorCallback(glfw_error_callback);
	if (!glfwInit())
		return 1;
	const char* glsl_version = "#version 130";
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	window = glfwCreateWindow(windowWidth * 2, windowHeight, "Chinese Ink-Wash Painterly Rendering Demo", nullptr, nullptr);
	if (!window) {
		std::cerr << "Cannot create window";
		std::exit(1);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1); // Enable vsync

	glfwSetKeyCallback(window, keyCallback);
	glfwSetMouseButtonCallback(window, mouseButtonCallback);
	glfwSetCursorPosCallback(window, cursorPosCallback);
	glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
	glfwSetScrollCallback(window, scrollCallback);

	//initOpenGL();
	assert(window);
	//if (gladLoadGLLoader((GLADloadproc)(glfwGetProcAddress)) == 0) {
	if (gladLoadGL() == 0) {
		std::cerr << "Failed to intialize OpenGL loader" << std::endl;
		std::exit(1);
	}
	assert(glGetError() == GL_NO_ERROR);
	glEnable(GL_DEPTH_TEST);

	// Setup Dear ImGui context
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;

	// Setup Dear ImGui style
	ImGui::StyleColorsDark();

	// Setup Platform/Renderer bindings
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init(glsl_version);

	ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

	prepareObject();
	prepareQuad();
	//glActiveTexture(GL_TEXTURE0 + kTextureUnitInUse_obj);
	tex_unit_objLoc = glGetUniformLocation(shader_p, "tex_unit_obj");
	//glActiveTexture(GL_TEXTURE0 + kTextureUnitInUse_bg);
	tex_unit_bgLoc = glGetUniformLocation(shader_p, "tex_unit_bg");

	mesh[0] = new Mesh("models/cow.obj");
	mesh[1] = new Mesh("models/cow.obj");
	prepareBackground("backgrounds/background4.jpg");

	while (!glfwWindowShouldClose(window)) {
		glfwPollEvents();
		glClearColor(1.0, 1.0, 1.0, 1.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Render the object, which is on the left side of the screen.
		for (int i = 0; i < 2; i++) {
			glUseProgram(shader_o[i]);
			glm::mat4 transform;
			float aspect = (float)windowWidth / (float)windowHeight;
			glm::mat4 proj = glm::perspective(45.0f, aspect, 0.1f, 100.0f);
			glm::mat4 view = glm::translate(glm::mat4(1.0f), { 0.0f, 0.0f, -camCoords.z });
			glm::mat4 rot = glm::rotate(glm::mat4(1.0f), glm::radians(camCoords.y), { 1.0f, 0.0f, 0.0f });
			rot = glm::rotate(rot, glm::radians(camCoords.x), { 0.0f, 1.0f, 0.0f });
			transform = proj * view * rot;
			auto meshBB = mesh[i]->boundingBox();
			float bboxDiagLength = glm::length(meshBB.second - meshBB.first);
			glm::mat4 fixBB = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f / bboxDiagLength));
			fixBB = glm::translate(fixBB, -(meshBB.first + meshBB.second) / 2.0f);
			transform = transform * fixBB;
			// cameraPos in model space
			glm::vec3 cameraPos = glm::vec3(glm::inverse(transform) * glm::vec4(0.0f, 0.0f, 0.0f, 1.0f));
			glm::mat4 translate = glm::translate(glm::mat4(1.0f), { Px, Py, 0.0f });
			transform = translate * transform;
			glUniformMatrix4fv(transformLoc[i], 1, GL_FALSE, glm::value_ptr(transform));
			glUniform1i(isPaintingLoc[i], i);
			for (int j = 0; j < 128; j++) {
				glUniform1f(texture1DLoc[i][j], texture1D[j]);
			}
			glUniform3f(cameraPosLoc[i], cameraPos.x, cameraPos.y, cameraPos.z);

			glViewport(i * windowWidth, 0, windowWidth, windowHeight); // 0 - left side, 1 - right side
			mesh[i]->draw(); 
			glBindVertexArray(0);
			glUseProgram(0);
			assert(glGetError() == GL_NO_ERROR);
		}

		// Render the painting, which is on the right side of the screen.
		preparePaintedObj();
		glUseProgram(shader_p);
		// Texture binding.
		glActiveTexture(GL_TEXTURE0 + kTextureUnitInUse_obj);
		glBindTexture(GL_TEXTURE_2D, texture_obj);
		glUniform1i(tex_unit_objLoc, kTextureUnitInUse_obj);
		glActiveTexture(GL_TEXTURE0 + kTextureUnitInUse_bg);
		glBindTexture(GL_TEXTURE_2D, texture_bg);
		glUniform1i(tex_unit_bgLoc, kTextureUnitInUse_bg);
		// Notice that no transformation is sent over to the shader
		//   (and the shader doesn't require one). By default OpenGL
		//   only draws everything inside the unit cube (x, y, z in [0, 1])
		//   so the 2 triangles will occupy most of the screen (but not all).
		glBindVertexArray(VAO_p);
		glViewport(windowWidth, 0, windowWidth, windowHeight);
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
		glBindVertexArray(0);
		glUseProgram(0);
		assert(glGetError() == GL_NO_ERROR);

		// Start the Dear ImGui frame
		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		// 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
		// 2. Show a simple window that we create ourselves. We use a Begin/End pair to created a named window.
		{
			static float f = 0.0f;
			static int counter = 0;

			ImGui::Begin("MENU");                          // Create a window called "Hello, world!" and append into it.

			static bool openFileDialog_obj = false;
			if (ImGui::Button("Select Object    ")) {
				openFileDialog_obj = true;
			}
			static std::string filePathName_obj = "";
			static std::string path_obj = "";
			static std::string fileName_obj = "";
			static std::string filter_obj = "";

			if (openFileDialog_obj)
			{
				if (ImGuiFileDialog::Instance()->FileDialog("Choose File", "\0", ".", ""))
				{
					if (ImGuiFileDialog::Instance()->IsOk == true)
					{
						filePathName_obj = ImGuiFileDialog::Instance()->GetFilepathName();
						path_obj = ImGuiFileDialog::Instance()->GetCurrentPath();
						fileName_obj = ImGuiFileDialog::Instance()->GetCurrentFileName();
						filter_obj = ImGuiFileDialog::Instance()->GetCurrentFilter();

						// print some useful information
						if (filePathName_obj.size() > 0) {
							for (int i = 0; i < 2; i++) {
								delete mesh[i];
								mesh[i] = new Mesh(filePathName_obj.c_str());
							}
						}
					}
					else {
						filePathName_obj = "";
						path_obj = "";
						fileName_obj = "";
						filter_obj = "";
					}
					openFileDialog_obj = false;
				}
			}

			if (fileName_obj.size() > 0) {
				ImGui::SameLine();
				ImGui::Text(fileName_obj.c_str());
			}

			static bool openFileDialog_img = false;
			if (ImGui::Button("Select Background")) {
				openFileDialog_img = true;
			}
			static std::string filePathName_img = "";
			static std::string path_img = "";
			static std::string fileName_img = "";
			static std::string filter_img = "";

			if (openFileDialog_img)
			{
				if (ImGuiFileDialog::Instance()->FileDialog("Choose File", "\0", ".", ""))
				{
					if (ImGuiFileDialog::Instance()->IsOk == true)
					{
						filePathName_img = ImGuiFileDialog::Instance()->GetFilepathName();
						path_img = ImGuiFileDialog::Instance()->GetCurrentPath();
						fileName_img = ImGuiFileDialog::Instance()->GetCurrentFileName();
						filter_img = ImGuiFileDialog::Instance()->GetCurrentFilter();

						// print some useful information
						if (filePathName_img.size() > 0) {
							//mesh = new Mesh(filePathName.c_str());
							prepareBackground(filePathName_img.c_str());
						}
					}
					else {
						filePathName_img = "";
						path_img = "";
						fileName_img = "";
						filter_img = "";
					}
					openFileDialog_img = false;
				}
			}

			if (fileName_img.size() > 0) {
				ImGui::SameLine();
				ImGui::Text(fileName_img.c_str());
			}

			ImGui::End();
		}

		// Rendering
		ImGui::Render();
		int display_w, display_h;
		glfwGetFramebufferSize(window, &display_w, &display_h);
		glViewport(0, 0, display_w, display_h);
		//glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
		//glClear(GL_COLOR_BUFFER_BIT);
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		glfwSwapBuffers(window);
	}

	// Cleanup
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();

	glfwDestroyWindow(window);
	glfwTerminate();

	return 0;
}


void prepareObject() {
	glEnable(GL_DEPTH_TEST);

	// Prepares the shader
	for (int i = 0; i < 2; i++) {
		std::vector<GLuint> shaders;
		shaders.push_back(compileShader(GL_VERTEX_SHADER, "obj_v.glsl"));
		shaders.push_back(compileShader(GL_FRAGMENT_SHADER, "obj_f.glsl"));
		shader_o[i] = linkProgram(shaders);
		transformLoc[i] = glGetUniformLocation(shader_o[i], "xform");
		isPaintingLoc[i] = glGetUniformLocation(shader_o[i], "isPainting");
		for (int j = 0; j < 128; j++) {
			texture1DLoc[i][j] = glGetUniformLocation(shader_o[i], 
				("texture1D[" + std::to_string(j) + "]").c_str());
		}
		cameraPosLoc[i] = glGetUniformLocation(shader_o[i], "cameraPos");
	}

	// Calculate the 1D texture
	for (int i = 0; i < 128; i++) {
		if (i / 128.0 <= 0.05) {
			texture1D[i] = 0.1;
		}
		//else if (i / 128.0 <= 0.28) {
		//	texture1D[i] = 0.20 + sin((i / 128.0 - 0.25) / 0.03 * M_PI / 2.0)*0.15;
		//}
		else if (i / 128.0 <= 0.2) {
			texture1D[i] = 0.3;
		}
		else if (i / 128.0 <= 0.5) {
			texture1D[i] = 0.7;
		}
		else if (i / 128.0 <= 1.0) {
			texture1D[i] = 1.0;
		}
	}
	// Apply gaussian filter to the texture for smooth ink-wash effect
	const int r = 7;
	const float sigma = 2.5;
	float gaussTemp[2 * r - 1];
	for (int i = 0; i < 2 * r - 1; i++) {
		gaussTemp[i] = exp(-pow((i - r), 2) / (2 * pow(sigma, 2)) / (sigma*sqrt(2 * M_PI)));
	}
	float texture1DTemp[128];
	for (int i = r; i < 128 - r; i++) {
		float sum1 = 0.0, sum2 = 0.0;
		for (int j = 0; j < 2 * r - 1; j++) {
			sum1 += texture1D[i - r + j] * gaussTemp[j];
			sum2 += gaussTemp[j];
		}
		texture1DTemp[i] = sum1 / sum2;
	}

	assert(glGetError() == GL_NO_ERROR);
}

void prepareQuad() {
	struct Vertex {
		glm::vec2 pos;
		glm::vec2 texture_uv;
	};

	// Vertices of the quad, which takes up 90% of the window both horizontally and vertically.
	std::vector<Vertex> verts = {
		{{-1.0f, -1.0f}, {0.0f, 1.0f}},	// bottom left
		{{ 1.0f, -1.0f}, {1.0f, 1.0f}},	// bottom right
		{{ 1.0f,  1.0f}, {1.0f, 0.0f}},	// top right
		{{-1.0f,  1.0f}, {0.0f, 0.0f}},	// top left
	};

	glGenVertexArrays(1, &VAO_p);
	glBindVertexArray(VAO_p);

	glGenBuffers(1, &VBO_p);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_p);
	glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(verts[0]), verts.data(), GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, texture_uv));

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// Prepares the shader
	std::vector<GLuint> shaders;
	shaders.push_back(compileShader(GL_VERTEX_SHADER, "painting_v.glsl"));
	shaders.push_back(compileShader(GL_FRAGMENT_SHADER, "painting_f.glsl"));
	shader_p = linkProgram(shaders);

	assert(glGetError() == GL_NO_ERROR);
}

// Return false if the user choosed an invalid image.
bool prepareBackground(const char * image_filename) {
	//constexpr int kImageDim = 1024;
	// The image is of size 1024x1024 and every pixel has 3 channels (RGB),
	//   each channel represented by 3 unsigned 8-bit numbers.
	//unsigned char * image_data = new unsigned char[kImageDim * kImageDim * 3];

	const char * filename = image_filename;
	int H = 0, W = 0, num_channels = 0;
	//stbi_set_flip_vertically_on_load(0);
	unsigned char * image_data = stbi_load(filename, &W, &H, &num_channels, 3);

	// Do some simple checking.
	if (image_data == nullptr) {
		std::cerr << "Image reading failed." << std::endl;
		return false;
	}
	else if (num_channels != 3 && num_channels != 4) {
		std::cerr << "The loaded image is not standard." << std::endl;
		std::cerr << "The loaded image doesn't have RGB color components." << std::endl;
		std::cerr << "The loaded image has " << num_channels << " channels." << std::endl;
		return false;
	}
	else {
		std::cout << "The image loaded has size " << W << "x" << H << "x" << num_channels << std::endl;
	}

	// Manages the memory data in `image_data` as an OpenGL texture.
	glGenTextures(1, &texture_bg);
	glBindTexture(GL_TEXTURE_2D, texture_bg);
	glTexImage2D(GL_TEXTURE_2D,				// The texture is 2D. (guess what, 1D and 3D are also supported by OpenGL.)
		0,							// level of mipmapping. Just make this 0.
		GL_RGB,					// How the image should be represented.
		W, H,		// width and height of the image
		0,							// Don't worry about this.
		GL_RGB,					// The format of the image data source. `image_data` has 3 channels.
		GL_UNSIGNED_BYTE,			// Data type of the image data source. `image_data` is an array of unsigned char.
		image_data);
	// Sets wrapping and filtering of the texture. Don't worry about them - just copy/paste.
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// Generates mipmapping for better sampling.
	glGenerateMipmap(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, 0);
	assert(glGetError() == GL_NO_ERROR);

	// stbi_load returns a piece of dynamically allocated memory.
	// As a good practice, the memory is released here.
	stbi_image_free(image_data);
	//delete[] image_data;

	return true;
}

// Return false if the user choosed an invalid image.
bool preparePaintedObj() {
	//constexpr int kImageDim = 1024;
	// The image is of size 1024x1024 and every pixel has 3 channels (RGB),
	//   each channel represented by 3 unsigned 8-bit numbers.
	//unsigned char * image_data = new unsigned char[kImageDim * kImageDim * 3];

	int H = 0, W = 0, num_channels = 0;
	unsigned char * image_data = new unsigned char[windowWidth * windowHeight * 3];
	glPixelStorei(GL_PACK_ALIGNMENT, 1);
	glReadPixels(windowWidth, 0, windowWidth, windowHeight, GL_RGB, GL_UNSIGNED_BYTE, image_data);
	//stbi_set_flip_vertically_on_load(true);
	stbi_write_jpg("models/object.jpg", windowWidth, windowHeight, 3, image_data, 300);
	//stbi_set_flip_vertically_on_load(1);
	delete[] image_data;
	image_data = stbi_load("models/object.jpg", &W, &H, &num_channels, 3);

	// Manages the memory data in `image_data` as an OpenGL texture.
	glGenTextures(1, &texture_obj);
	glBindTexture(GL_TEXTURE_2D, texture_obj);
	glTexImage2D(GL_TEXTURE_2D,				// The texture is 2D. (guess what, 1D and 3D are also supported by OpenGL.)
		0,							// level of mipmapping. Just make this 0.
		GL_RGB,					// How the image should be represented.
		W, H,		// width and height of the image
		0,							// Don't worry about this.
		GL_RGB,					// The format of the image data source. `image_data` has 3 channels.
		GL_UNSIGNED_BYTE,			// Data type of the image data source. `image_data` is an array of unsigned char.
		image_data);
	// Sets wrapping and filtering of the texture. Don't worry about them - just copy/paste.
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// Generates mipmapping for better sampling.
	glGenerateMipmap(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, 0);
	assert(glGetError() == GL_NO_ERROR);

	// stbi_load returns a piece of dynamically allocated memory.
	// As a good practice, the memory is released here.
	stbi_image_free(image_data);

	return true;
}

// GLFW window callbacks
// --------------------------------------------------------------------

void scrollCallback(GLFWwindow* w, double x, double y) {
	float offset = (y > 0) ? 0.1f : -0.1f;
	camCoords.z = glm::clamp(camCoords.z - offset, 0.1f, 10.0f);
}

void keyCallback(GLFWwindow* w, int key, int scancode, int action, int mode) {
	if (key == GLFW_KEY_ESCAPE && action == GLFW_RELEASE) {
		glfwSetWindowShouldClose(w, true);
	}
	if (key == GLFW_KEY_UP && action == GLFW_RELEASE) {
		Py += 0.05;
	}
	if (key == GLFW_KEY_DOWN && action == GLFW_RELEASE) {
		Py -= 0.05;
	}
	if (key == GLFW_KEY_RIGHT && action == GLFW_RELEASE) {
		Px += 0.05;
	}
	if (key == GLFW_KEY_LEFT && action == GLFW_RELEASE) {
		Px -= 0.05;
	}
}

void mouseButtonCallback(GLFWwindow* w, int button, int action, int mode) {
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		// Activate rotation mode
		double xpos, ypos;
		glfwGetCursorPos(w, &xpos, &ypos);
		if (xpos > windowWidth) { // only mouse click at the left half side of the window is valid
			return;
		}
		mouseOrigin = glm::vec2(xpos, ypos);
		camRot = true;
		camOrigin = glm::vec2(camCoords);
	} 
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE) {
		camRot = false;
		//std::cout << camCoords.x << " " << camCoords.y << " " << camCoords.z << std::endl;
	}
}

void cursorPosCallback(GLFWwindow* w, double xp, double yp) {
	if (camRot) {
		float rotScale = std::fmin(windowWidth / 450.f, windowHeight / 270.f);
		glm::vec2 mouseDelta = glm::vec2(xp, yp) - mouseOrigin;
		glm::vec2 newAngle = camOrigin + mouseDelta / rotScale;
		newAngle.y = glm::clamp(newAngle.y, -90.0f, 90.0f);
		while (newAngle.x > 180.0f) newAngle.x -= 360.0f;
		while (newAngle.y < -180.0f) newAngle.y += 360.0f;
		if (glm::length(newAngle - glm::vec2(camCoords)) > std::numeric_limits<float>::epsilon()) {
			camCoords.x = newAngle.x;
			camCoords.y = newAngle.y;
		}
	}
}

void framebufferSizeCallback(GLFWwindow* w, int width, int height) {
	::windowWidth = width;
	::windowHeight = height;
	glViewport(0, 0, width/2, height);
}